# Upgrading to v10.0.0

The v10.0 release contains backwards-incompatible changes.

This update requires upgrading the minimum provider version of `hashicorp/google` from `3.50` to `5.8` and `hashicorp/google-beta` from `3.50` to `6.13`.
